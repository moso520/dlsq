#coding=utf-8
import sys
def Path(path):
	sys.path.append("C:\\dlsq\\donglishequ\\" + path)
	return True