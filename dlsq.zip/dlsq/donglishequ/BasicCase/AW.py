#coding=utf-8
from selenium import webdriver
import time
import sys
import os
sys.path.append("C:\\dlsq\\donglishequ\\Path")
import common
common.Path("BaseData")
global driver
driver = webdriver.Ie()



def login(url,user,password):
	###########################
	'''DEFname:login
	@auther:moso
	parameter:url：网址,user：用户名,;password:密码
	exp：login("www.baidu.com","moso001","123456")
	'''
	############################


	return True