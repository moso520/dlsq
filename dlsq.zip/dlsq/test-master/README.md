﻿# test
python+selenium自动化测试框架
这是我自己使用的一个自动化框架，包含组织用例，批量运行，生成运行日志，html报告，
自动发送邮件到指定邮箱（公司外网有限制，我的不能使用）
使用po设计模式封装，

注：没有生成excel报告，多浏览器、多线程、分布式执行等模块，后续会继续添加，丰富自动化框架

常用的文件在soft文件夹中

robotframework运行时后台报错UnicodeDecodeError:https://blog.csdn.net/qq_29720415/article/details/53542662

command: pybot.bat --argumentfile c:\users\keikei\appdata\local\temp\RIDEama2ym.d\argfile.txt --list
https://blog.csdn.net/nv_li_jcf/article/details/77917447
