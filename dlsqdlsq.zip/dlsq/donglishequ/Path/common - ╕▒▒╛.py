#coding=utf-8
from selenium import webdriver
driver = webdriver.Chrome()
driver.get('http://localhost:8088/upload/forum.php')
div_1 = driver.find_element_by_partial_link_text('0')
for i  in div_1:
	print(i)
print(div_1)
'''
for div in divs:
	if 

'''