#coding=utf-8
import csv
data = csv.reader(open('D:\\python\\dlsq\\Basic_file\\1.csv','rb'))
for i in data:
        print (i)
