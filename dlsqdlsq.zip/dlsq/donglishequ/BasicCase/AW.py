#coding=utf-8
from selenium import webdriver
import time
import sys
import os
import unittest
sys.path.append("C:\\dlsq\\donglishequ\\Path")
sys.path.append("C:\\dlsq\\test-master\\page")
from basePage import Page
import common
common.Path("BaseData")
global driver
driver = webdriver.Chrome()


class Web (object):
	def __init__(self, driver):
		self.driver = driver
	# url="http://localhost:8088/upload/forum.php"
	def login(url,user,password):
		###########################
		'''DEFname:login
		@auther:moso
		parameter:url：网址,user：用户名,;password:密码
		exp：login("www.baidu.com","moso001","123456")
		'''
		############################


		return True

	def register(self,url,name,password,email):
		driver = self.driver
		x = Page(driver)
		driver.get(url)
		time.sleep(2)
		x.click(('xpath','//*[@id="lsform"]/div/div/table/tbody/tr[2]/td[4]/a'))
		# x.click(('id','lsform'))
		x.send_keys(('id','4B4BHK'),name)
		x.send_keys(('id','r37n7r'),password)
		x.send_keys(('id','q0k9ja'),password)
		x.send_keys(('id','1j8Sy3'),email)
		x.click(('xpath','//*[@id="registerformsubmit"]/strong'))
		y = x.get_text(('xpath','//*[@id="um"]/p[1]/a[4]'))
		return True
	def get_register_result(self):
		driver = self.driver
		x = Page(driver)
		y = x.get_text(('xpath','//*[@id="um"]/p[1]/a[4]'))
		return y

