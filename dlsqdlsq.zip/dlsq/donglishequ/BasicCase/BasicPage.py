#coding=utf-8
from selenium.webdriver.support.ui import WebDriverWait
import time,sys.os

class BasePage():


	def __init__(self,driver):
		self.driver = driver

	def find_element(self,locator,timeout=10):
		
		