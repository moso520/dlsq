#coding=utf-8
String={
	"BaseUrl":"http://localhost:8088/upload/forum.php",
	"user001":"moso001",
	"user002":"moso002",
	"user003":"moso003",
	"user004":"moso004",
	"user005":"moso005",
	"password":"123456",
	"Email001":"123001@163.com",
	"Email002":"123002@163.com",
	"Email003":"123003@163.com",
	"Email004":"123004@163.com",
	"Email005":"123005@163.com",
	"Email006":"123006@163.com"





}