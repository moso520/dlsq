#ecoding = "utf-8"
import sys,os,re
from selenium import webdriver
import unittest
import HTMLTestRunner
sys.path.append("C:\\dlsq\\test-master\\page")
from basePage import Page
sys.path.append("C:\\dlsq\\donglishequ\\BasicCase")
from AW import Web
#步骤
#(driver)---->初始化函数调用
# Page(driver).is_text(('id','ls_fastloginfield_ctrl'),"用户名")
#实例化
class DLSQ(unittest.TestCase):
	url="http://localhost:8088/upload/forum.php"
	def setUp(self):
		self.driver = webdriver.Chrome()
	# @unittest.skip('调试')
	def test001(self):
		driver=self.driver
		x=Page(driver)
		driver.get(self.url)
		try:
			y = x.get_text(('id','ls_fastloginfield_ctrl'))
			self.assertEqual(y,'用户名')
		except Exception as e:
			print("filed")
	# 	# finally:

	def test002(self):
		driver=self.driver
		x=Page(driver)
		driver.get(self.url)
		y=x.get_attribute(('id','ls_fastloginfield_ctrl'),'sytle')
		print(y)
	# @unittest.skip('调试')
	def test003(self):
		driver=self.driver
		x=Page(driver)
		driver.get(self.url)
		xx = x.get_title()
		print(xx)
	# @unittest.skip('调试')
	def test004(self):
		driver = self.driver
		x = Web(driver)
		x.register(self.url,'mos01189','admin','www.1151@163.com')
		if x.get_register_result() == '退出' :
			print('register successful!!!')


	def tearDown(self):
		self.driver.quit()
		os.system('taskill /f /im chromedriver.exe')






if __name__ == '__main__':
	# unittest.main()
	#定义一个测试集
	testunit = unittest.TestSuite()
	testunit.addTest(DLSQ("test001"))
	testunit.addTest(DLSQ("test002"))
	testunit.addTest(DLSQ("test003"))
	testunit.addTest(DLSQ("test004"))

	filename = 'C:\\dlsq\\donglishequ\\Report\\result1.html'
	fp = open(filename,'wb')
	runner =HTMLTestRunner.HTMLTestRunner(
	stream=fp,
	title=u'dlsq测试报告',
	description=u'用例执行情况：')
	# fp.close()

	runner.run(testunit)