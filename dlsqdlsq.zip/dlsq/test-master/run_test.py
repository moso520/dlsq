from run_test import report,mail

#调用函数，读取用例，生成报告

report.report()

#调用函数，读取最新报告，并发送邮件附件

#mail.mail()
